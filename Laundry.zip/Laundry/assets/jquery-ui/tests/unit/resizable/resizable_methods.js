/*
 * resizable_methods.js
 */
(function($) {

module("resizable: methods");

// this is here to make JSHint pass "unused", and we don't want to
// remove the parameter for when we finally implement
$.noop();

})(jQuery);
