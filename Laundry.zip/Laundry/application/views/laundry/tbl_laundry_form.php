<div class="content-wrapper">
    
    <section class="content">
        <div class="box box-warning box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">DATA LAUNDRY</h3>
            </div>
            <form action="<?php echo $action; ?>" method="post">
            
<table class='table table-bordered>'        

	    <tr><td width='200'>Nama Pelanggan <?php echo form_error('Nama_Pelanggan') ?></td><td><input type="text" class="form-control" name="Nama_Pelanggan" id="Nama_Pelanggan" placeholder="Nama Pelanggan" value="<?php echo $Nama_Pelanggan; ?>" /></td></tr>
	    <tr><td width='200'>Tipe Laundry <?php echo form_error('Tipe_Laundry') ?></td><td><input type="text" class="form-control" name="Tipe_Laundry" id="Tipe_Laundry" placeholder="Tipe Laundry" value="<?php echo $Tipe_Laundry; ?>" /></td></tr>
	    <tr><td width='200'>Harga <?php echo form_error('Harga') ?></td><td><input type="text" class="form-control" name="Harga" id="Harga" placeholder="Harga" value="<?php echo $Harga; ?>" /></td></tr>
	    <tr><td width='200'>Tanggal Order <?php echo form_error('Tanggal_Order') ?></td><td><input type="date" class="form-control" name="Tanggal_Order" id="Tanggal_Order" placeholder="Tanggal Order" value="<?php echo $Tanggal_Order; ?>" /></td></tr>
	    <tr><td width='200'>Tanggal Jadi <?php echo form_error('Tanggal_Jadi') ?></td><td><input type="date" class="form-control" name="Tanggal_Jadi" id="Tanggal_Jadi" placeholder="Tanggal Jadi" value="<?php echo $Tanggal_Jadi; ?>" /></td></tr>
	    <tr><td></td><td><input type="hidden" name="id_transaksi" value="<?php echo $id_transaksi; ?>" /> 
	    <button type="submit" class="btn btn-danger"><i class="fa fa-floppy-o"></i> <?php echo $button ?></button> 
	    <a href="<?php echo site_url('laundry') ?>" class="btn btn-info"><i class="fa fa-sign-out"></i> Kembali</a></td></tr>
	</table></form>        </div>
</div>
</div>