<div class="content-wrapper">
    
    <section class="content">
        <div class="box box-warning box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">DATA PELANGGAN</h3>
            </div>
            <form action="<?php echo $action; ?>" method="post">
            
<table class='table table-bordered>'        

	    <tr><td width='200'>Nama Pelanggan <?php echo form_error('Nama_Pelanggan') ?></td><td><input type="text" class="form-control" name="Nama_Pelanggan" id="Nama_Pelanggan" placeholder="Nama Pelanggan" value="<?php echo $Nama_Pelanggan; ?>" /></td></tr>
	    <tr><td width='200'>No HP <?php echo form_error('No_HP') ?></td><td><input type="text" class="form-control" name="No_HP" id="No_HP" placeholder="No HP" value="<?php echo $No_HP; ?>" /></td></tr>
	    <tr><td width='200'>Alamat <?php echo form_error('Alamat') ?></td><td><input type="text" class="form-control" name="Alamat" id="Alamat" placeholder="Alamat" value="<?php echo $Alamat; ?>" /></td></tr>
	    <tr><td></td><td><input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    <button type="submit" class="btn btn-danger"><i class="fa fa-floppy-o"></i> <?php echo $button ?></button> 
	    <a href="<?php echo site_url('pelanggan') ?>" class="btn btn-info"><i class="fa fa-sign-out"></i> Kembali</a></td></tr>
	</table></form>        </div>
</div>
</div>