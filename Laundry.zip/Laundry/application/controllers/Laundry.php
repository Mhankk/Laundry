<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Laundry extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        is_login();
        $this->load->model('Laundry_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->uri->segment(3));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . '.php/c_url/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'index.php/laundry/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'index.php/laundry/index/';
            $config['first_url'] = base_url() . 'index.php/laundry/index/';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = FALSE;
        $config['total_rows'] = $this->Laundry_model->total_rows($q);
        $laundry = $this->Laundry_model->get_limit_data($config['per_page'], $start, $q);
        $config['full_tag_open'] = '<ul class="pagination pagination-sm no-margin pull-right">';
        $config['full_tag_close'] = '</ul>';
        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'laundry_data' => $laundry,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $this->template->load('template','laundry/tbl_laundry_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Laundry_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_transaksi' => $row->id_transaksi,
		'Nama_Pelanggan' => $row->Nama_Pelanggan,
		'Tipe_Laundry' => $row->Tipe_Laundry,
		'Harga' => $row->Harga,
		'Tanggal_Order' => $row->Tanggal_Order,
		'Tanggal_Jadi' => $row->Tanggal_Jadi,
	    );
            $this->template->load('template','laundry/tbl_laundry_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('laundry'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('laundry/create_action'),
	    'id_transaksi' => set_value('id_transaksi'),
	    'Nama_Pelanggan' => set_value('Nama_Pelanggan'),
	    'Tipe_Laundry' => set_value('Tipe_Laundry'),
	    'Harga' => set_value('Harga'),
	    'Tanggal_Order' => set_value('Tanggal_Order'),
	    'Tanggal_Jadi' => set_value('Tanggal_Jadi'),
	);
        $this->template->load('template','laundry/tbl_laundry_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'Nama_Pelanggan' => $this->input->post('Nama_Pelanggan',TRUE),
		'Tipe_Laundry' => $this->input->post('Tipe_Laundry',TRUE),
		'Harga' => $this->input->post('Harga',TRUE),
		'Tanggal_Order' => $this->input->post('Tanggal_Order',TRUE),
		'Tanggal_Jadi' => $this->input->post('Tanggal_Jadi',TRUE),
	    );

            $this->Laundry_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success 2');
            redirect(site_url('laundry'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Laundry_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('laundry/update_action'),
		'id_transaksi' => set_value('id_transaksi', $row->id_transaksi),
		'Nama_Pelanggan' => set_value('Nama_Pelanggan', $row->Nama_Pelanggan),
		'Tipe_Laundry' => set_value('Tipe_Laundry', $row->Tipe_Laundry),
		'Harga' => set_value('Harga', $row->Harga),
		'Tanggal_Order' => set_value('Tanggal_Order', $row->Tanggal_Order),
		'Tanggal_Jadi' => set_value('Tanggal_Jadi', $row->Tanggal_Jadi),
	    );
            $this->template->load('template','laundry/tbl_laundry_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('laundry'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_transaksi', TRUE));
        } else {
            $data = array(
		'Nama_Pelanggan' => $this->input->post('Nama_Pelanggan',TRUE),
		'Tipe_Laundry' => $this->input->post('Tipe_Laundry',TRUE),
		'Harga' => $this->input->post('Harga',TRUE),
		'Tanggal_Order' => $this->input->post('Tanggal_Order',TRUE),
		'Tanggal_Jadi' => $this->input->post('Tanggal_Jadi',TRUE),
	    );

            $this->Laundry_model->update($this->input->post('id_transaksi', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('laundry'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Laundry_model->get_by_id($id);

        if ($row) {
            $this->Laundry_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('laundry'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('laundry'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('Nama_Pelanggan', 'nama pelanggan', 'trim|required');
	$this->form_validation->set_rules('Tipe_Laundry', 'tipe laundry', 'trim|required');
	$this->form_validation->set_rules('Harga', 'harga', 'trim|required');
	$this->form_validation->set_rules('Tanggal_Order', 'tanggal order', 'trim|required');
	$this->form_validation->set_rules('Tanggal_Jadi', 'tanggal jadi', 'trim|required');

	$this->form_validation->set_rules('id_transaksi', 'id_transaksi', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Laundry.php */
/* Location: ./application/controllers/Laundry.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-09-05 18:36:18 */
/* http://harviacode.com */